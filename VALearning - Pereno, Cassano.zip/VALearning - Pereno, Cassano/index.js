var carosello = [
    {
        imgpath: "https://www.tecnicadellascuola.it/wp-content/uploads/2022/07/Matematica_Casella-300x194.jpg",
        titolo: "Risolvi gli esercizi",
        desc:"...."
    },
    {
        imgpath: "https://www.tecnicadellascuola.it/wp-content/uploads/2022/07/Matematica_Casella-300x194.jpg",
        titolo: "Risolvi gli esercizi",
        desc:"...."
    },
    {
        imgpath: "https://www.tecnicadellascuola.it/wp-content/uploads/2022/07/Matematica_Casella-300x194.jpg",
        titolo: "Risolvi gli esercizi",
        desc:"...."
    },
    {
        imgpath: "https://www.tecnicadellascuola.it/wp-content/uploads/2022/07/Matematica_Casella-300x194.jpg",
        titolo: "Risolvi gli esercizi",
        desc:"...."
    }
];