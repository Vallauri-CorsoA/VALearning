let nEsercizi;


function listaEsercizi(){

    const anchors = document.querySelectorAll('a');
    const transition_el = document.querySelector('.transition');

    let time = 500;
    setTimeout(() => {
        transition_el.classList.remove('is-active');
        if (time == 1000) {
            document.getElementById("navbar").style.display = "none";
        }
    }, time);

    for (let i = 0; i < anchors.length; i++) {
        const anchor = anchors[i];

        anchor.addEventListener('click', e => {
            e.preventDefault();
        let target = e.target.href;

        transition_el.classList.add('is-active');

        setInterval(() => {
            window.location.href = target;
        }, time);
        })
    }


    contaEsercizi();
    for(let i = 0; i < nEsercizi; i++){
        vediEsercizi(i);
    }

}

function contaEsercizi(){
    nEsercizi = 10;
    // Forzato in modo da vedere qualcosa, nEsercizi dovrà esere uguale al numero di esercizi presenti nel DataBase e stamparne il numero corretto

    return nEsercizi;
}

function vediEsercizi(i){

    const a= document.getElementById("main");

    
    let esercizi = 
    `
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Tipologia esercizio</h5>
            <p class="card-text">Proposto da: </p>
            <button class="learn-more" onclick="visualizzaEsercizio()">
                <span class="circle" aria-hidden="true">
                    <span class="icon arrow"></span>
                </span>
                <span class="button-text">VISUALIZZA</span>
            </button> 
            
        
        </div>
    </div>
    `; // Dal DataBase ricevere il Nome di chio ha proposto l'esercizio

    a.innerHTML += esercizi;
}

function visualizzaEsercizio(){
    let pagina =
    `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VALearning</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

        <link href="index.css" rel="stylesheet">
        <link href="conferma.css" rel="stylesheet">
        <link href="transition.css" rel="stylesheet">

        <script src="index.js"></script>
        <script src="conferma.js"></script>

    </head>
    <body onload="listaesErcizi()">
        <div class="transition transition-3"></div>
        <header>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="conferma.html">Conferma Esercizi</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <button class="btn btn-primary" type="submit">Login</button>
                    </form>
                    </div>
                </div>
            </nav>
        </header>
        <main>
        
            <div class="container"> 
                <div class="row">
                    <div class="col-md-6" id ="visualizzazioneContenuto">
                        <h1>VISUALIZZARE ESERCIZIO</h1>
                        
                    </div>
                    <div class="col-md-6">
                        <section id="areaComandi">
                            <div id="commento">
                                <textarea cols="40" rows="5" class="sezioneCommenti" placeholder="scrivi un commento"></textarea>
                                <button id ="invia">INVIA</button>
                            </div>
                            <div>
                                <div class="sezioneTag">
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Mixed tenses</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Actions in progression</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Irregular verbs</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Active/Passive</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Reported Speech</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Mixed futures</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Rephrasing</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Exercises with Wish</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Would rather / prefer</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Conditionals</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Phrasal Verbs</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Make or Do</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Causative Verbs</button>
                                    <button type="button" class="item-button col-bg-4" onclick="cambiaBtn" value = 0>Modal Verbs</button>
                                </div>
                            </div>
                            <div class="button">
                                <button id ="btnAccetta" onclick="accettaEsercizio()">ACCETTA</button>
                                <button id ="btnRifiuta" onclick="rifiutaEsercizio()">RIFIUTA</button>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

            
        </main>
        <footer>
            Creato dalla 3 A INF nel 2023
        </footer>
    </body>
    </html>
    `;
    // Nel Main verrà visualizzato l'esercizio preso in una sezione del server

    document.write(pagina);
}

function accettaEsercizio(){
    // Bisogna tornare alla pagina della visualizzazione dellgli Esercizi
    // Bisogna Eliminare l'Esercizio dalla sezione server deglla Conferma Esercizi
}

function rifiutaEsercizio(){
    // Bisogna tornare alla pagina della visualizzazione dellgli Esercizi
    // Bisogna "Rispedire" l'Esecizio all'Utente che l'ha Proposto
}

function scriviCommento(){
    const a = document.getElementById("main");

    
    let esercizi = 
    `
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Tipologia esercizio</h5>
            <p class="card-text">Proposto da: </p>
            <button class="learn-more" onclick="visualizzaEsercizio()">
                <span class="circle" aria-hidden="true">
                    <span class="icon arrow"></span>
                </span>
                <span class="button-text">VISUALIZZA</span>
            </button>         
        </div>
    </div>
    `; // Dal DataBase ricevere il Nome di chio ha proposto l'esercizio

    a.innerHTML += esercizi;
}

function cambiaBtn(){
    se
}









