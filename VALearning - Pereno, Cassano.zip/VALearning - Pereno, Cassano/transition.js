window.onload = () => {
    const anchors = document.querySelectorAll('a');
    const transition_el = document.querySelector('.transition');

    let time = 500;
    setTimeout(() => {
        transition_el.classList.remove('is-active');
        if (time == 500) {
            document.getElementById("navbar").style.display = "none";
        }
    }, time);

    for (let i = 0; i < anchors.length; i++) {
        const anchor = anchors[i];

        anchor.addEventListener('click', e => {
            e.preventDefault();
        let target = e.target.href;

        transition_el.classList.add('is-active');

        setInterval(() => {
            window.location.href = target;
        }, time);
        })
    }
}